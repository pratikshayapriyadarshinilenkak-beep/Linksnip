
import axios from 'axios'

export const API_URL =
  import.meta.env.VITE_API_URL || 'http://localhost:8081'

const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json'
  }
})

// Automatically attach JWT to every API request
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('linksnip_token')

    if (token) {
      config.headers.Authorization = `Bearer ${token}`
    }

    return config
  },
  (error) => Promise.reject(error)
)

export const authApi = {
  register: (data) =>
    api.post('/api/auth/register', data),

  login: (data) =>
    api.post('/api/auth/login', data)
}

export const linksApi = {
  create: (data) =>
    api.post('/api/links', data),

  mine: () =>
    api.get('/api/links/mine'),

  get: (id) =>
    api.get(`/api/links/${id}`),

  update: (id, data) =>
    api.put(`/api/links/${id}`, data),

  remove: (id) =>
    api.delete(`/api/links/${id}`),

  analytics: (id) =>
    api.get(`/api/analytics/${id}`),

  // QR CODE
  // JWT is automatically added by the interceptor above.
  qr: (id) =>
    api.get(`/api/qr/${id}`, {
      responseType: 'blob'
    }),

  // Analytics CSV
  exportAnalytics: (id) =>
    api.get(`/api/export/analytics/${id}`, {
      responseType: 'blob'
    }),

  // Bulk CSV import
  bulkImport: (file) => {
    const form = new FormData()

    form.append('file', file)

    return api.post('/api/bulk/import', form, {
      headers: {
        'Content-Type': 'multipart/form-data'
      }
    })
  }
}

export default api

