import React, { useEffect, useState } from "react";
import { createRoot } from "react-dom/client";
import { BrowserRouter, Navigate, Route, Routes } from "react-router-dom";
import "./styles.css";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Dashboard from "./pages/Dashboard";
import CreateLink from "./pages/CreateLink";
import Analytics from "./pages/Analytics";
import BulkImport from "./pages/BulkImport";

function Protected({ children }) {
  return localStorage.getItem("linksnip_token") ? (
    children
  ) : (
    <Navigate to="/login" replace />
  );
}

function App() {
  const [, setAuth] = useState(!!localStorage.getItem("linksnip_token"));
  useEffect(() => {
    const sync = () => setAuth(!!localStorage.getItem("linksnip_token"));
    window.addEventListener("storage", sync);
    return () => window.removeEventListener("storage", sync);
  }, []);
  return (
    <Routes>
      <Route
        path="/"
        element={
          <Navigate
            to={
              localStorage.getItem("linksnip_token") ? "/dashboard" : "/login"
            }
            replace
          />
        }
      />
      <Route path="/login" element={<Login onAuth={() => setAuth(true)} />} />
      <Route path="/register" element={<Register />} />
      <Route
        path="/dashboard"
        element={
          <Protected>
            <Dashboard />
          </Protected>
        }
      />
      <Route
        path="/links/new"
        element={
          <Protected>
            <CreateLink />
          </Protected>
        }
      />
      <Route
        path="/analytics/:id"
        element={
          <Protected>
            <Analytics />
          </Protected>
        }
      />
      <Route
        path="/bulk"
        element={
          <Protected>
            <BulkImport />
          </Protected>
        }
      />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <BrowserRouter>
      <App />
    </BrowserRouter>
  </React.StrictMode>,
);
