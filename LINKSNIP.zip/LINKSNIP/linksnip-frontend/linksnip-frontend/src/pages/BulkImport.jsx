import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { linksApi } from '../services/api'

export default function CreateLink() {
  const navigate = useNavigate()

  const [form, setForm] = useState({
    originalUrl: '',
    customAlias: '',
    expiresAt: '',
    maxClicks: '',
    tags: '',
    folder: ''
  })

  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')
  const [createdLink, setCreatedLink] = useState(null)

  const handleChange = (e) => {
    const { name, value } = e.target

    setForm((prev) => ({
      ...prev,
      [name]: value
    }))
  }

  const handleSubmit = async (e) => {
    e.preventDefault()

    setError('')
    setSuccess('')
    setCreatedLink(null)

    if (!form.originalUrl.trim()) {
      setError('Please enter a URL.')
      return
    }

    setLoading(true)

    try {
      const payload = {
        originalUrl: form.originalUrl.trim(),
        customAlias:
          form.customAlias.trim() || null,
        expiresAt:
          form.expiresAt || null,
        maxClicks:
          form.maxClicks
            ? Number(form.maxClicks)
            : null,
        tags:
          form.tags.trim() || null,
        folder:
          form.folder.trim() || null
      }

      const response =
        await linksApi.create(payload)

      setCreatedLink(response.data)

      setSuccess(
        'Short link created successfully.'
      )

      setForm({
        originalUrl: '',
        customAlias: '',
        expiresAt: '',
        maxClicks: '',
        tags: '',
        folder: ''
      })

    } catch (err) {
      console.error(err)

      setError(
        err.response?.data?.message ||
        err.response?.data ||
        'Failed to create short link.'
      )

    } finally {
      setLoading(false)
    }
  }

  const copyLink = async () => {
    if (!createdLink) return

    const shortUrl =
      createdLink.shortUrl ||
      createdLink.shortLink ||
      `${window.location.origin}/${createdLink.shortCode}`

    try {
      await navigator.clipboard.writeText(
        shortUrl
      )

      setSuccess(
        'Short URL copied to clipboard.'
      )
    } catch (err) {
      console.error(err)

      setError(
        'Unable to copy the short URL.'
      )
    }
  }

  return (
    <div className="page-container">

      <div className="page-header">

        <div>
          <h1>Create Short Link</h1>

          <p>
            Create a short URL and manage
            its settings.
          </p>
        </div>

      </div>

      <div className="card create-link-card">

        <form onSubmit={handleSubmit}>

          {/* Original URL */}

          <div className="form-group">

            <label htmlFor="originalUrl">
              Original URL
            </label>

            <input
              id="originalUrl"
              name="originalUrl"
              type="url"
              value={form.originalUrl}
              onChange={handleChange}
              placeholder="https://example.com/your-long-url"
              required
            />

          </div>

          {/* Custom Alias */}

          <div className="form-group">

            <label htmlFor="customAlias">
              Custom Alias
            </label>

            <input
              id="customAlias"
              name="customAlias"
              type="text"
              value={form.customAlias}
              onChange={handleChange}
              placeholder="my-link"
              maxLength={30}
            />

            <small>
              3–30 characters. Letters,
              numbers and hyphens only.
            </small>

          </div>

          {/* Expiration */}

          <div className="form-group">

            <label htmlFor="expiresAt">
              Expiration
            </label>

            <input
              id="expiresAt"
              name="expiresAt"
              type="datetime-local"
              value={form.expiresAt}
              onChange={handleChange}
            />

            <small>
              Leave empty if the link should
              never expire.
            </small>

          </div>

          {/* Maximum Clicks */}

          <div className="form-group">

            <label htmlFor="maxClicks">
              Maximum Clicks
            </label>

            <input
              id="maxClicks"
              name="maxClicks"
              type="number"
              min="1"
              value={form.maxClicks}
              onChange={handleChange}
              placeholder="Unlimited"
            />

            <small>
              Leave empty for unlimited clicks.
            </small>

          </div>

          {/* Tags */}

          <div className="form-group">

            <label htmlFor="tags">
              Tags
            </label>

            <input
              id="tags"
              name="tags"
              type="text"
              value={form.tags}
              onChange={handleChange}
              placeholder="marketing, campaign"
            />

          </div>

          {/* Folder */}

          <div className="form-group">

            <label htmlFor="folder">
              Folder
            </label>

            <input
              id="folder"
              name="folder"
              type="text"
              value={form.folder}
              onChange={handleChange}
              placeholder="Marketing"
            />

          </div>

          {/* Error */}

          {error && (
            <div className="error-message">
              {error}
            </div>
          )}

          {/* Success */}

          {success && (
            <div className="success-message">
              {success}
            </div>
          )}

          {/* Buttons */}

          <div className="form-actions">

            <button
              type="button"
              className="secondary-button"
              onClick={() =>
                navigate('/dashboard')
              }
            >
              Cancel
            </button>

            <button
              type="submit"
              className="primary-button"
              disabled={loading}
            >
              {loading
                ? 'Creating...'
                : 'Create Short Link'}
            </button>

          </div>

        </form>

      </div>

      {/* Created link */}

      {createdLink && (

        <div className="card created-link-card">

          <h2>
            Short Link Created
          </h2>

          <div className="created-link-box">

            <a
              href={
                createdLink.shortUrl ||
                createdLink.shortLink ||
                `${window.location.origin}/${createdLink.shortCode}`
              }
              target="_blank"
              rel="noreferrer"
            >
              {createdLink.shortUrl ||
                createdLink.shortLink ||
                `${window.location.origin}/${createdLink.shortCode}`}
            </a>

            <button
              type="button"
              onClick={copyLink}
            >
              Copy
            </button>

          </div>

          <button
            type="button"
            className="primary-button"
            onClick={() =>
              navigate('/dashboard')
            }
          >
            Go to Dashboard
          </button>

        </div>

      )}

    </div>
  )
}