
import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import {
  BarChart3,
  Copy,
  ExternalLink,
  Plus,
  QrCode,
  Trash2,
  X
} from 'lucide-react'

import Layout from '../components/Layout'
import { linksApi, API_URL } from '../services/api'

export default function Dashboard() {

  const [links, setLinks] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  // QR modal state
  const [qrUrl, setQrUrl] = useState(null)
  const [qrLoading, setQrLoading] = useState(false)
  const [qrError, setQrError] = useState('')

  const load = async () => {

    try {

      const response = await linksApi.mine()

      setLinks(response.data || [])

    } catch (error) {

      setError(
        error.response?.data?.message ||
        'Could not load links.'
      )

    } finally {

      setLoading(false)

    }
  }

  useEffect(() => {
    load()
  }, [])

  // Delete link
  const remove = async (id) => {

    if (!window.confirm('Delete this link?')) {
      return
    }

    try {

      await linksApi.remove(id)

      setLinks((currentLinks) =>
        currentLinks.filter(
          (link) => link.id !== id
        )
      )

    } catch (error) {

      window.alert(
        error.response?.data?.message ||
        'Delete failed.'
      )

    }
  }

  // Copy short URL
  const copy = async (url) => {

    try {

      await navigator.clipboard.writeText(url)

      window.alert('Short URL copied!')

    } catch (error) {

      console.error(error)

      window.alert(
        'Could not copy the URL.'
      )
    }
  }

  // Load QR code using JWT
  const showQrCode = async (linkId) => {

    setQrLoading(true)
    setQrError('')
    setQrUrl(null)

    try {

      const response = await linksApi.qr(linkId)

      // Convert PNG blob into browser URL
      const imageUrl =
        URL.createObjectURL(response.data)

      setQrUrl(imageUrl)

    } catch (error) {

      console.error('QR error:', error)

      setQrError(
        error.response?.data?.message ||
        'Could not load QR code.'
      )

    } finally {

      setQrLoading(false)

    }
  }

  // Close QR modal
  const closeQr = () => {

    if (qrUrl) {
      URL.revokeObjectURL(qrUrl)
    }

    setQrUrl(null)
    setQrError('')
  }

  return (

    <Layout>

      {/* Page Header */}
      <div className="page-head">

        <div>

          <h1>My links</h1>

          <p className="muted">
            Create, manage and measure your short links.
          </p>

        </div>

        <Link
          className="primary button-link"
          to="/links/new"
        >
          <Plus size={18} />
          Create link
        </Link>

      </div>


      {/* Statistics */}
      <div className="stat-row">

        <div className="stat">

          <span>Total links</span>

          <strong>
            {links.length}
          </strong>

        </div>


        <div className="stat">

          <span>Total clicks</span>

          <strong>
            {links.reduce(
              (total, link) =>
                total + (link.clickCount || 0),
              0
            )}
          </strong>

        </div>

      </div>


      {/* Error */}
      {error && (
        <div className="error">
          {error}
        </div>
      )}


      {/* Loading */}
      {loading ? (

        <div className="empty">
          Loading links...
        </div>

      ) : links.length === 0 ? (

        /* No links */
        <div className="empty">

          <div className="empty-icon">
            ↗
          </div>

          <h3>
            No links yet
          </h3>

          <p>
            Create your first short link
            to see it here.
          </p>

          <Link
            className="primary button-link"
            to="/links/new"
          >
            Create link
          </Link>

        </div>

      ) : (

        /* Link list */
        <div className="link-list">

          {links.map((link) => {

            const shortUrl =
              link.shortUrl ||
              `${API_URL}/${link.customAlias || link.shortCode}`

            return (

              <div
                className="link-card"
                key={link.id}
              >

                {/* Link information */}
                <div className="link-main">

                  <div className="link-icon">
                    ↗
                  </div>

                  <div className="link-info">

                    <div className="link-title">

                      <a
                        href={shortUrl}
                        target="_blank"
                        rel="noreferrer"
                      >
                        {link.customAlias ||
                          link.shortCode}
                      </a>

                      <ExternalLink size={14} />

                    </div>


                    <div className="destination">

                      {link.originalUrl}

                    </div>


                    <div className="meta">

                      {link.clickCount || 0} clicks

                      {' · '}

                      {link.active === false
                        ? 'Inactive'
                        : 'Active'}

                      {link.folder
                        ? ` · ${link.folder}`
                        : ''}

                    </div>

                  </div>

                </div>


                {/* Actions */}
                <div className="card-actions">

                  {/* Copy */}
                  <button
                    title="Copy short URL"
                    onClick={() =>
                      copy(shortUrl)
                    }
                  >
                    <Copy size={17} />
                  </button>


                  {/* Analytics */}
                  <Link
                    title="Analytics"
                    to={`/analytics/${link.id}`}
                  >
                    <BarChart3 size={17} />
                  </Link>


                  {/* QR */}
                  <button
                    title="Show QR Code"
                    onClick={() =>
                      showQrCode(link.id)
                    }
                  >
                    <QrCode size={17} />
                  </button>


                  {/* Delete */}
                  <button
                    title="Delete"
                    onClick={() =>
                      remove(link.id)
                    }
                  >
                    <Trash2 size={17} />
                  </button>

                </div>

              </div>

            )

          })}

        </div>

      )}


      {/* QR MODAL */}
      {(qrLoading || qrUrl || qrError) && (

        <div
          className="qr-overlay"
          onClick={closeQr}
        >

          <div
            className="qr-modal"
            onClick={(event) =>
              event.stopPropagation()
            }
          >

            {/* Close */}
            <button
              className="qr-close"
              onClick={closeQr}
              title="Close"
            >
              <X size={22} />
            </button>


            <h2>
              QR Code
            </h2>


            {qrLoading && (

              <div className="qr-loading">

                <p>
                  Generating QR code...
                </p>

              </div>

            )}


            {qrError && (

              <div className="error">

                {qrError}

              </div>

            )}


            {qrUrl && !qrLoading && (

              <div className="qr-content">

                <img
                  src={qrUrl}
                  alt="Link QR Code"
                  className="qr-image"
                />

                <p className="qr-url">

                  Scan this QR code to open
                  your short link.

                </p>

              </div>

            )}

          </div>

        </div>

      )}

    </Layout>
  )
}

