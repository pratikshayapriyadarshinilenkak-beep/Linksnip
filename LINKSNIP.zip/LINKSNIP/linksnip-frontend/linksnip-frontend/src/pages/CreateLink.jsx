import { useState } from "react";
import { useNavigate } from "react-router-dom";
import Layout from "../components/Layout";
import { linksApi } from "../services/api";
export default function CreateLink() {
  const nav = useNavigate();
  const [form, setForm] = useState({
    originalUrl: "",
    customAlias: "",
    expiresAt: "",
    maxClicks: "",
    tags: "",
    folder: "",
    password: "",
  });
  const [error, setError] = useState("");
  const [created, setCreated] = useState(null);
  const [loading, setLoading] = useState(false);
  const update = (k, v) => setForm({ ...form, [k]: v });
  const submit = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const data = { ...form };
      if (!data.customAlias) delete data.customAlias;
      if (!data.expiresAt) delete data.expiresAt;
      if (!data.maxClicks) data.maxClicks = null;
      else data.maxClicks = Number(data.maxClicks);
      if (!data.tags) delete data.tags;
      if (!data.folder) delete data.folder;
      if (!data.password) delete data.password;
      const r = await linksApi.create(data);
      setCreated(r.data);
    } catch (err) {
      setError(err.response?.data?.message || "Could not create link.");
    } finally {
      setLoading(false);
    }
  };
  return (
    <Layout>
      <div className="page-head">
        <div>
          <h1>Create short link</h1>
          <p className="muted">Turn a long URL into a shareable LinkSnip.</p>
        </div>
      </div>
      {created ? (
        <div className="result-card">
          <div className="success">Link created successfully.</div>
          <h3>Your short URL</h3>
          <a
            className="short-url"
            href={created.shortUrl}
            target="_blank"
            rel="noreferrer"
          >
            {created.shortUrl}
          </a>
          <div className="actions">
            <button
              className="primary"
              onClick={() => navigator.clipboard.writeText(created.shortUrl)}
            >
              Copy link
            </button>
            <button className="secondary" onClick={() => nav("/dashboard")}>
              Go to dashboard
            </button>
          </div>
        </div>
      ) : (
        <form className="form-card" onSubmit={submit}>
          <label>
            Destination URL *
            <input
              type="url"
              required
              placeholder="https://example.com/your-page"
              value={form.originalUrl}
              onChange={(e) => update("originalUrl", e.target.value)}
            />
          </label>
          <div className="grid-2">
            <label>
              Custom alias
              <input
                placeholder="my-link"
                value={form.customAlias}
                onChange={(e) => update("customAlias", e.target.value)}
              />
            </label>
            <label>
              Folder
              <input
                placeholder="Marketing"
                value={form.folder}
                onChange={(e) => update("folder", e.target.value)}
              />
            </label>
            <label>
              Tags
              <input
                placeholder="campaign, social"
                value={form.tags}
                onChange={(e) => update("tags", e.target.value)}
              />
            </label>
            <label>
              Max clicks
              <input
                type="number"
                min="1"
                placeholder="Unlimited"
                value={form.maxClicks}
                onChange={(e) => update("maxClicks", e.target.value)}
              />
            </label>
            <label>
              Expires at
              <input
                type="datetime-local"
                value={form.expiresAt}
                onChange={(e) => update("expiresAt", e.target.value)}
              />
            </label>
            <label>
              Password protection
              <input
                type="password"
                placeholder="Optional"
                value={form.password}
                onChange={(e) => update("password", e.target.value)}
              />
            </label>
          </div>
          {error && <div className="error">{error}</div>}
          <button className="primary" disabled={loading}>
            {loading ? "Creating…" : "Create short link"}
          </button>
        </form>
      )}
    </Layout>
  );
}
