import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { ArrowLeft, Download } from "lucide-react";
import Layout from "../components/Layout";
import { linksApi } from "../services/api";
export default function Analytics() {
  const { id } = useParams();
  const [data, setData] = useState(null);
  const [error, setError] = useState("");
  useEffect(() => {
    linksApi
      .analytics(id)
      .then((r) => setData(r.data))
      .catch((e) =>
        setError(e.response?.data?.message || "Could not load analytics."),
      );
  }, [id]);
  const download = async () => {
    const r = await linksApi.exportAnalytics(id);
    const url = URL.createObjectURL(r.data);
    const a = document.createElement("a");
    a.href = url;
    a.download = `link-${id}-analytics.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };
  return (
    <Layout>
      <div className="page-head">
        <div>
          <Link className="back" to="/dashboard">
            <ArrowLeft size={16} /> Back to links
          </Link>
          <h1>Analytics</h1>
          <p className="muted">Click activity for link #{id}.</p>
        </div>
        <button className="secondary" onClick={download}>
          <Download size={17} /> Export CSV
        </button>
      </div>
      {error && <div className="error">{error}</div>}
      <div className="stat-row">
        <div className="stat">
          <span>Total clicks</span>
          <strong>{data?.totalClicks ?? "—"}</strong>
        </div>
      </div>
      <div className="table-card">
        <table>
          <thead>
            <tr>
              <th>Time</th>
              <th>IP</th>
              <th>Referrer</th>
              <th>Device</th>
              <th>Browser</th>
              <th>Location</th>
            </tr>
          </thead>
          <tbody>
            {(data?.clicks || []).map((c, i) => (
              <tr key={c.id || i}>
                <td>
                  {c.clickedAt ? new Date(c.clickedAt).toLocaleString() : "—"}
                </td>
                <td>{c.ipAddress || "—"}</td>
                <td>{c.referrer || "Direct"}</td>
                <td>{c.device || "—"}</td>
                <td>{c.browser || "—"}</td>
                <td>{[c.city, c.country].filter(Boolean).join(", ") || "—"}</td>
              </tr>
            ))}
          </tbody>
        </table>
        {data && data.clicks?.length === 0 && (
          <div className="empty small">No clicks recorded yet.</div>
        )}
      </div>
    </Layout>
  );
}
