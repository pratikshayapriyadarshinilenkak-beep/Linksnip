import { Link, useNavigate } from "react-router-dom";
import { BarChart3, Link2, LogOut, Plus, Upload } from "lucide-react";

export default function Layout({ children }) {
  const navigate = useNavigate();
  const email = localStorage.getItem("linksnip_email") || "Account";
  const logout = () => {
    localStorage.removeItem("linksnip_token");
    localStorage.removeItem("linksnip_email");
    navigate("/login");
  };
  return (
    <div className="app-shell">
      <aside className="sidebar">
        <Link to="/dashboard" className="brand">
          <span className="brand-mark">S</span> LinkSnip
        </Link>
        <nav>
          <Link to="/dashboard">
            <Link2 size={18} /> My Links
          </Link>
          <Link to="/links/new">
            <Plus size={18} /> Create Link
          </Link>
          <Link to="/bulk">
            <Upload size={18} /> Bulk Import
          </Link>
        </nav>
        <div className="sidebar-bottom">
          <div className="user-mini">
            <div className="avatar">{email[0]?.toUpperCase()}</div>
            <span>{email}</span>
          </div>
          <button className="ghost-btn" onClick={logout}>
            <LogOut size={17} /> Logout
          </button>
        </div>
      </aside>
      <main className="main-content">{children}</main>
    </div>
  );
}
