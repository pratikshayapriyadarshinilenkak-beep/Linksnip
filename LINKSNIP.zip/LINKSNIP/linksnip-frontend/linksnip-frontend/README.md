# LinkSnip React Frontend

React + Vite frontend for the LinkSnip Spring Boot backend.

## Backend URL

The frontend defaults to:

`http://localhost:8081`

To change it, create `.env` from `.env.example`:

`VITE_API_URL=http://localhost:8081`

## Run in Eclipse/terminal

1. Install Node.js 20+.
2. Open a terminal in this folder.
3. Run:

```bash
npm install
npm run dev
```

4. Open `http://localhost:5173`.

## Features

- Register / login with JWT
- Dashboard with user's links
- Create short links
- Custom aliases
- Expiration, max clicks, tags and folders
- Copy/open short links
- Delete links
- Analytics page
- CSV analytics export
- QR code access
- Bulk CSV import
- Responsive layout

## Expected backend

Spring Boot backend running on port 8081 with these endpoints:

- POST /api/auth/register
- POST /api/auth/login
- POST /api/links
- GET /api/links/mine
- GET /api/links/{id}
- PUT /api/links/{id}
- DELETE /api/links/{id}
- GET /api/analytics/{id}
- GET /api/qr/{id}
- POST /api/bulk/import
- GET /api/export/analytics/{id}
