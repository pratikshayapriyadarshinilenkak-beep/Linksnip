# LinkSnip Backend

Spring Boot + MySQL + JPA + JWT backend for the LinkSnip URL shortener.

## 1. MySQL
```sql
CREATE DATABASE linksnip;
```

## 2. application.properties
Set:
- `spring.datasource.password`
- `linksnip.jwt-secret` (32+ characters)

## 3. Eclipse
Import as **Existing Maven Project**, Maven > Update Project, then Run As > Spring Boot App.

## API
- `POST /api/auth/register`
- `POST /api/auth/login`
- `POST /api/links` (public; custom alias requires JWT)
- `GET /api/links/mine` (JWT)
- `GET /api/links/{id}` (JWT)
- `PUT /api/links/{id}` (JWT)
- `DELETE /api/links/{id}` (JWT)
- `GET /{code}` redirect
- `GET /api/analytics/{linkId}` (JWT)
- `GET /api/qr/{linkId}` (JWT)
- `POST /api/bulk/import` (JWT; CSV header: `originalUrl`)
- `GET /api/export/analytics/{linkId}` (JWT)

Authenticated requests use:
`Authorization: Bearer <token>`

The database tables are created/updated automatically with `spring.jpa.hibernate.ddl-auto=update`.
