package com.linksnip.controller;

import com.linksnip.dto.BulkLinkResult;
import com.linksnip.service.BulkImportService;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/api/bulk")
public class BulkController {
	private final BulkImportService service;

	public BulkController(BulkImportService service) {
		this.service = service;
	}

	@PostMapping("/import")
	public List<BulkLinkResult> importCsv(@RequestParam("file") MultipartFile file, Authentication a)
			throws IOException {
		return service.importCsv(file, a.getName());
	}
}
