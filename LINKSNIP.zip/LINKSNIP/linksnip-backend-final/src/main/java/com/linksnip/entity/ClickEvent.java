package com.linksnip.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "click_events", indexes = @Index(name = "idx_click_link_time", columnList = "link_id,clickedAt"))
public class ClickEvent {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "link_id", nullable = false)
	private Link link;
	@Column(nullable = false)
	private LocalDateTime clickedAt;
	@Column(length = 100)
	private String ipAddress;
	@Column(length = 500)
	private String referrer;
	@Column(length = 1000)
	private String userAgent;
	@Column(length = 50)
	private String device;
	@Column(length = 50)
	private String browser;
	@Column(length = 100)
	private String country;
	@Column(length = 100)
	private String city;

	@PrePersist
	protected void onCreate() {
		if (clickedAt == null)
			clickedAt = LocalDateTime.now();
	}

	public ClickEvent() {
	}

	public Long getId() {
		return id;
	}

	public Link getLink() {
		return link;
	}

	public void setLink(Link v) {
		link = v;
	}

	public LocalDateTime getClickedAt() {
		return clickedAt;
	}

	public String getIpAddress() {
		return ipAddress;
	}

	public void setIpAddress(String v) {
		ipAddress = v;
	}

	public String getReferrer() {
		return referrer;
	}

	public void setReferrer(String v) {
		referrer = v;
	}

	public String getUserAgent() {
		return userAgent;
	}

	public void setUserAgent(String v) {
		userAgent = v;
	}

	public String getDevice() {
		return device;
	}

	public void setDevice(String v) {
		device = v;
	}

	public String getBrowser() {
		return browser;
	}

	public void setBrowser(String v) {
		browser = v;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String v) {
		country = v;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String v) {
		city = v;
	}
}
