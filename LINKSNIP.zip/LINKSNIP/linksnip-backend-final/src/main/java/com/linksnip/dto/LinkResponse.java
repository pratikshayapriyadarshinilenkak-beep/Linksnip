package com.linksnip.dto;

import java.time.LocalDateTime;

public record LinkResponse(Long id, String originalUrl, String shortCode, String shortUrl, String customAlias,
		LocalDateTime createdAt, LocalDateTime expiresAt, Long maxClicks, boolean active, long clickCount, String tags,
		String folder, boolean passwordProtected) {
}
