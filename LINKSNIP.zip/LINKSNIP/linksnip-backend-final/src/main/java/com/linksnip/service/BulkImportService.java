package com.linksnip.service;

import com.linksnip.dto.*;
import org.apache.commons.csv.*;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

@Service
public class BulkImportService {
	private final LinkService links;

	public BulkImportService(LinkService links) {
		this.links = links;
	}

	public List<BulkLinkResult> importCsv(MultipartFile file, String email) throws IOException {
		if (file.isEmpty())
			throw new IllegalArgumentException("CSV file is empty");
		List<BulkLinkResult> out = new ArrayList<>();
		try (Reader r = new InputStreamReader(file.getInputStream(), StandardCharsets.UTF_8);
				CSVParser p = CSVFormat.DEFAULT.builder().setHeader().setSkipHeaderRecord(true).get().parse(r)) {
			int row = 1;
			for (CSVRecord rec : p) {
				String url = rec.get("originalUrl");
				try {
					LinkResponse x = links.create(new CreateLinkRequest(url, null, null, null, null, null, null),
							email);
					out.add(new BulkLinkResult(row, url, x.shortUrl(), null));
				} catch (Exception e) {
					out.add(new BulkLinkResult(row, url, null, e.getMessage()));
				}
				row++;
			}
		} catch (IllegalArgumentException e) {
			throw new IllegalArgumentException("CSV must contain an originalUrl header");
		}
		return out;
	}
}
