package com.linksnip.dto;

public record BulkLinkResult(int row, String originalUrl, String shortUrl, String error) {
}
