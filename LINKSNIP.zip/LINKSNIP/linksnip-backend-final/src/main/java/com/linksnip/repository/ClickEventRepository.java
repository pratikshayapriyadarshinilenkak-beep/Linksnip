package com.linksnip.repository;

import com.linksnip.entity.ClickEvent;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface ClickEventRepository extends JpaRepository<ClickEvent, Long> {
	List<ClickEvent> findByLinkIdOrderByClickedAtDesc(Long linkId);
}
