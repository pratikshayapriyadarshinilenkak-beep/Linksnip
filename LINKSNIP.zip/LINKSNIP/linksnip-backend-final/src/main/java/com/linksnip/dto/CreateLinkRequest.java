package com.linksnip.dto;

import jakarta.validation.constraints.*;
import java.time.LocalDateTime;

public record CreateLinkRequest(@NotBlank @Size(max = 2048) String originalUrl,
		@Size(min = 3, max = 30) String customAlias, LocalDateTime expiresAt, Long maxClicks, String tags,
		String folder, @Size(max = 100) String password) {
}
