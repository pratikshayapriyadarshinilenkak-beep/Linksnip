package com.linksnip.service;

import com.linksnip.entity.ClickEvent;
import com.linksnip.entity.Link;
import com.linksnip.exception.ResourceNotFoundException;
import com.linksnip.repository.ClickEventRepository;
import com.linksnip.repository.LinkRepository;
import org.apache.commons.csv.*;
import org.springframework.stereotype.Service;
import java.io.*;
import java.nio.charset.StandardCharsets;

@Service
public class AnalyticsExportService {
	private final LinkRepository links;
	private final ClickEventRepository events;

	public AnalyticsExportService(LinkRepository links, ClickEventRepository events) {
		this.links = links;
		this.events = events;
	}

	public byte[] export(Long id, String email) throws IOException {
		Link l = links.findByIdAndUserEmail(id, email)
				.orElseThrow(() -> new ResourceNotFoundException("Link not found"));
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		try (Writer w = new OutputStreamWriter(out, StandardCharsets.UTF_8);
				CSVPrinter p = new CSVPrinter(w, CSVFormat.DEFAULT.builder()
						.setHeader("timestamp", "ip", "referrer", "device", "browser", "country", "city").build())) {
			for (ClickEvent e : events.findByLinkIdOrderByClickedAtDesc(id))
				p.printRecord(e.getClickedAt(), e.getIpAddress(), e.getReferrer(), e.getDevice(), e.getBrowser(),
						e.getCountry(), e.getCity());
		}
		return out.toByteArray();
	}
}
