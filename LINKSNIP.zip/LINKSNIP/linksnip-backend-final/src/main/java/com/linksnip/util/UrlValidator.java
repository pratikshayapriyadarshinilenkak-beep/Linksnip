package com.linksnip.util;

import org.springframework.stereotype.Component;
import java.net.URI;

@Component
public class UrlValidator {
	public boolean isValid(String url) {
		try {
			URI u = new URI(url);
			String s = u.getScheme();
			return ("http".equalsIgnoreCase(s) || "https".equalsIgnoreCase(s)) && u.getHost() != null;
		} catch (Exception e) {
			return false;
		}
	}
}
