package com.linksnip.util;

import org.springframework.stereotype.Component;
import java.security.SecureRandom;

@Component
public class ShortCodeGenerator {
	private static final String CHARS = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
	private final SecureRandom random = new SecureRandom();

	public String generateCode() {
		StringBuilder b = new StringBuilder(7);
		for (int i = 0; i < 7; i++)
			b.append(CHARS.charAt(random.nextInt(CHARS.length())));
		return b.toString();
	}
}
