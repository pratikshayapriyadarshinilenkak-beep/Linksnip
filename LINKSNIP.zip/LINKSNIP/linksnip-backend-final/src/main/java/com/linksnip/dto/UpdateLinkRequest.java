package com.linksnip.dto;

import jakarta.validation.constraints.*;
import java.time.LocalDateTime;

public record UpdateLinkRequest(@NotBlank @Size(max = 2048) String originalUrl, String customAlias,
		LocalDateTime expiresAt, Long maxClicks, Boolean active, String tags, String folder,
		@Size(max = 100) String password) {
}
