package com.linksnip.controller;

import com.linksnip.entity.*;
import com.linksnip.repository.*;
import com.linksnip.service.LinkService;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.net.URI;

@RestController
public class RedirectController {
	private final LinkService service;
	private final LinkRepository links;
	private final ClickEventRepository events;

	public RedirectController(LinkService service, LinkRepository links, ClickEventRepository events) {
		this.service = service;
		this.links = links;
		this.events = events;
	}

	@GetMapping("/{code}")
	public ResponseEntity<Void> redirect(@PathVariable String code, @RequestParam(required = false) String password,
			HttpServletRequest req) {
		Link l = service.resolve(code);
		service.checkUsable(l, password);
		l.setClickCount(l.getClickCount() + 1);
		ClickEvent e = new ClickEvent();
		e.setLink(l);
		e.setIpAddress(clientIp(req));
		e.setReferrer(req.getHeader("Referer"));
		e.setUserAgent(req.getHeader("User-Agent"));
		e.setDevice(device(e.getUserAgent()));
		e.setBrowser(browser(e.getUserAgent()));
		events.save(e);
		links.save(l);
		return ResponseEntity.status(HttpStatus.FOUND).location(URI.create(l.getOriginalUrl())).build();
	}

	private String clientIp(HttpServletRequest r) {
		String x = r.getHeader("X-Forwarded-For");
		return x == null ? r.getRemoteAddr() : x.split(",")[0].trim();
	}

	private String device(String u) {
		if (u == null)
			return "Unknown";
		String x = u.toLowerCase();
		return x.contains("mobile") || x.contains("android") || x.contains("iphone") ? "Mobile"
				: x.contains("ipad") || x.contains("tablet") ? "Tablet" : "Desktop";
	}

	private String browser(String u) {
		if (u == null)
			return "Unknown";
		if (u.contains("Edg/"))
			return "Edge";
		if (u.contains("Chrome/"))
			return "Chrome";
		if (u.contains("Firefox/"))
			return "Firefox";
		if (u.contains("Safari/") && !u.contains("Chrome/"))
			return "Safari";
		return "Other";
	}
}
