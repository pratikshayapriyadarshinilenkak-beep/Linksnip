package com.linksnip.service;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import com.linksnip.entity.Link;
import com.linksnip.repository.LinkRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;

@Service
public class QrCodeService {

    private final LinkRepository linkRepository;

    @Value("${linksnip.base-url}")
    private String baseUrl;

    public QrCodeService(LinkRepository linkRepository) {
        this.linkRepository = linkRepository;
    }

    public byte[] generateQrCode(
            Long linkId,
            String email
    ) {

        Link link = linkRepository
                .findByIdAndUserEmail(linkId, email)
                .orElseThrow(() ->
                        new RuntimeException(
                                "Link not found or you do not have permission"
                        )
                );

        String shortUrl;

        if (link.getCustomAlias() != null
                && !link.getCustomAlias().isBlank()) {

            shortUrl = baseUrl + "/" + link.getCustomAlias();

        } else {

            shortUrl = baseUrl + "/" + link.getShortCode();
        }

        try {

            QRCodeWriter qrCodeWriter = new QRCodeWriter();

            BitMatrix bitMatrix = qrCodeWriter.encode(
                    shortUrl,
                    BarcodeFormat.QR_CODE,
                    300,
                    300
            );

            ByteArrayOutputStream outputStream =
                    new ByteArrayOutputStream();

            MatrixToImageWriter.writeToStream(
                    bitMatrix,
                    "PNG",
                    outputStream
            );

            return outputStream.toByteArray();

        } catch (WriterException e) {

            throw new RuntimeException(
                    "Failed to generate QR code",
                    e
            );
        } catch (Exception e) {

            throw new RuntimeException(
                    "Failed to create QR code image",
                    e
            );
        }
    }
}
