package com.linksnip.repository;

import com.linksnip.entity.Link;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.*;

public interface LinkRepository extends JpaRepository<Link, Long> {
	Optional<Link> findByShortCode(String shortCode);

	Optional<Link> findByCustomAlias(String customAlias);

	boolean existsByShortCode(String shortCode);

	boolean existsByCustomAlias(String customAlias);

	List<Link> findByUserEmailOrderByCreatedAtDesc(String email);

	Optional<Link> findByIdAndUserEmail(Long id, String email);
}
