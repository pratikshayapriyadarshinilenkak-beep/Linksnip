package com.linksnip.controller;

import com.linksnip.service.AnalyticsExportService;
import org.springframework.http.*;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/export")
public class ExportController {
	private final AnalyticsExportService service;

	public ExportController(AnalyticsExportService service) {
		this.service = service;
	}

	@GetMapping(value = "/analytics/{linkId}", produces = "text/csv")
	public ResponseEntity<byte[]> export(@PathVariable Long linkId, Authentication a) throws Exception {
		return ResponseEntity.ok()
				.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=analytics-" + linkId + ".csv")
				.body(service.export(linkId, a.getName()));
	}
}
