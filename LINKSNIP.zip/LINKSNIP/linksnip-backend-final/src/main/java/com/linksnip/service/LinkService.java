package com.linksnip.service;

import com.linksnip.dto.*;
import com.linksnip.entity.Link;
import com.linksnip.entity.User;
import com.linksnip.exception.ResourceNotFoundException;
import com.linksnip.repository.LinkRepository;
import com.linksnip.repository.UserRepository;
import com.linksnip.util.ShortCodeGenerator;
import com.linksnip.util.UrlValidator;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class LinkService {
	private final LinkRepository links;
	private final UserRepository users;
	private final ShortCodeGenerator generator;
	private final UrlValidator validator;
	private final PasswordEncoder encoder;
	private final String baseUrl;

	public LinkService(LinkRepository links, UserRepository users, ShortCodeGenerator generator, UrlValidator validator,
			PasswordEncoder encoder, @Value("${linksnip.base-url:http://localhost:8080}") String baseUrl) {
		this.links = links;
		this.users = users;
		this.generator = generator;
		this.validator = validator;
		this.encoder = encoder;
		this.baseUrl = baseUrl.replaceAll("/$", "");
	}

	public LinkResponse create(CreateLinkRequest r, String email) {
		validate(r.originalUrl(), r.expiresAt(), r.maxClicks());
		String alias = alias(r.customAlias());
		if (alias != null && email == null)
			throw new IllegalArgumentException("Login is required for a custom alias");
		if (alias != null && links.existsByCustomAlias(alias))
			throw new IllegalArgumentException("Custom alias already exists");
		Link l = new Link();
		l.setOriginalUrl(r.originalUrl().trim());
		l.setShortCode(uniqueCode());
		l.setCustomAlias(alias);
		l.setExpiresAt(r.expiresAt());
		l.setMaxClicks(r.maxClicks());
		l.setTags(r.tags());
		l.setFolder(r.folder());
		if (r.password() != null && !r.password().isBlank())
			l.setPasswordHash(encoder.encode(r.password()));
		if (email != null)
			l.setUser(users.findByEmail(email).orElseThrow(() -> new ResourceNotFoundException("User not found")));
		return response(links.save(l));
	}

	public List<LinkResponse> mine(String email) {
		return links.findByUserEmailOrderByCreatedAtDesc(email).stream().map(this::response).toList();
	}

	public LinkResponse getMine(Long id, String email) {
		return response(owned(id, email));
	}

	public LinkResponse update(Long id, String email, UpdateLinkRequest r) {
		Link l = owned(id, email);
		validate(r.originalUrl(), r.expiresAt(), r.maxClicks());
		String a = alias(r.customAlias());
		if (a != null && !a.equals(l.getCustomAlias()) && links.existsByCustomAlias(a))
			throw new IllegalArgumentException("Custom alias already exists");
		l.setOriginalUrl(r.originalUrl().trim());
		l.setCustomAlias(a);
		l.setExpiresAt(r.expiresAt());
		l.setMaxClicks(r.maxClicks());
		l.setTags(r.tags());
		l.setFolder(r.folder());
		if (r.active() != null)
			l.setActive(r.active());
		if (r.password() != null)
			l.setPasswordHash(r.password().isBlank() ? null : encoder.encode(r.password()));
		return response(links.save(l));
	}

	public void delete(Long id, String email) {
		links.delete(owned(id, email));
	}

	public Link resolve(String code) {
		return links.findByCustomAlias(code).or(() -> links.findByShortCode(code))
				.orElseThrow(() -> new ResourceNotFoundException("Short link not found"));
	}

	public void checkUsable(Link l, String password) {
		if (!l.isActive())
			throw new IllegalArgumentException("Link is disabled");
		if (l.getExpiresAt() != null && !l.getExpiresAt().isAfter(LocalDateTime.now()))
			throw new IllegalArgumentException("Link has expired");
		if (l.getMaxClicks() != null && l.getClickCount() >= l.getMaxClicks())
			throw new IllegalArgumentException("Link click limit reached");
		if (l.getPasswordHash() != null && (password == null || !encoder.matches(password, l.getPasswordHash())))
			throw new IllegalArgumentException("Password required or incorrect");
	}

	private Link owned(Long id, String email) {
		return links.findByIdAndUserEmail(id, email).orElseThrow(() -> new ResourceNotFoundException("Link not found"));
	}

	private void validate(String u, LocalDateTime exp, Long max) {
		if (!validator.isValid(u))
			throw new IllegalArgumentException("Invalid HTTP/HTTPS URL");
		if (exp != null && !exp.isAfter(LocalDateTime.now()))
			throw new IllegalArgumentException("Expiration must be in the future");
		if (max != null && max < 1)
			throw new IllegalArgumentException("maxClicks must be at least 1");
	}

	private String alias(String a) {
		if (a == null || a.isBlank())
			return null;
		a = a.trim();
		if (!a.matches("[A-Za-z0-9-]{3,30}"))
			throw new IllegalArgumentException("Alias must be 3-30 characters using letters, numbers and hyphens");
		return a;
	}

	private String uniqueCode() {
		String c;
		do {
			c = generator.generateCode();
		} while (links.existsByShortCode(c));
		return c;
	}

	private LinkResponse response(Link l) {
		String c = l.getCustomAlias() != null ? l.getCustomAlias() : l.getShortCode();
		return new LinkResponse(l.getId(), l.getOriginalUrl(), l.getShortCode(), baseUrl + "/" + c, l.getCustomAlias(),
				l.getCreatedAt(), l.getExpiresAt(), l.getMaxClicks(), l.isActive(), l.getClickCount(), l.getTags(),
				l.getFolder(), l.getPasswordHash() != null);
	}
}
