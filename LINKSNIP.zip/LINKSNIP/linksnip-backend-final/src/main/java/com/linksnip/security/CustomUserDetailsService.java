package com.linksnip.security;

import com.linksnip.repository.UserRepository;
import org.springframework.security.core.userdetails.*;
import org.springframework.stereotype.Service;

@Service
public class CustomUserDetailsService implements UserDetailsService {
	private final UserRepository repo;

	public CustomUserDetailsService(UserRepository repo) {
		this.repo = repo;
	}

	@Override
	public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
		return repo.findByEmail(email)
				.map(u -> User.withUsername(u.getEmail()).password(u.getPassword()).roles("USER")
						.disabled(!u.isEnabled()).build())
				.orElseThrow(() -> new UsernameNotFoundException("User not found"));
	}
}
