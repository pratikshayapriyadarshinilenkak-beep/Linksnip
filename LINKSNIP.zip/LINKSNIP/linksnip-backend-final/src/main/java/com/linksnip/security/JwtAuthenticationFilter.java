package com.linksnip.security;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

@Component
public class JwtAuthenticationFilter extends OncePerRequestFilter {
	private final JwtService jwt;
	private final CustomUserDetailsService users;

	public JwtAuthenticationFilter(JwtService jwt, CustomUserDetailsService users) {
		this.jwt = jwt;
		this.users = users;
	}

	@Override
	protected void doFilterInternal(HttpServletRequest req, HttpServletResponse res, FilterChain chain)
			throws ServletException, IOException {
		String h = req.getHeader("Authorization");
		if (StringUtils.hasText(h) && h.startsWith("Bearer ")) {
			String t = h.substring(7);
			if (jwt.valid(t) && SecurityContextHolder.getContext().getAuthentication() == null) {
				String e = jwt.username(t);
				UserDetails u = users.loadUserByUsername(e);
				var a = new UsernamePasswordAuthenticationToken(u, null, u.getAuthorities());
				a.setDetails(new WebAuthenticationDetailsSource().buildDetails(req));
				SecurityContextHolder.getContext().setAuthentication(a);
			}
		}
		chain.doFilter(req, res);
	}
}
