package com.linksnip.dto;

public record AuthResponse(String token, String email) {
}
