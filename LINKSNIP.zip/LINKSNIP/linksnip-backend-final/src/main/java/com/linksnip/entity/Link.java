package com.linksnip.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "links", indexes = @Index(name = "idx_link_short_code", columnList = "shortCode"))
public class Link {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	@Column(nullable = false, length = 2048)
	private String originalUrl;
	@Column(nullable = false, unique = true, length = 30)
	private String shortCode;
	@Column(unique = true, length = 30)
	private String customAlias;
	@Column(nullable = false)
	private LocalDateTime createdAt;
	private LocalDateTime expiresAt;
	private Long maxClicks;
	@Column(nullable = false)
	private boolean active = true;
	@Column(nullable = false)
	private long clickCount = 0;
	@Column(length = 1000)
	private String tags;
	@Column(length = 100)
	private String folder;
	@Column(length = 100)
	private String passwordHash;
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "user_id")
	private User user;

	@PrePersist
	protected void onCreate() {
		if (createdAt == null)
			createdAt = LocalDateTime.now();
	}

	public Link() {
	}

	public Long getId() {
		return id;
	}

	public String getOriginalUrl() {
		return originalUrl;
	}

	public void setOriginalUrl(String v) {
		originalUrl = v;
	}

	public String getShortCode() {
		return shortCode;
	}

	public void setShortCode(String v) {
		shortCode = v;
	}

	public String getCustomAlias() {
		return customAlias;
	}

	public void setCustomAlias(String v) {
		customAlias = v;
	}

	public LocalDateTime getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(LocalDateTime v) {
		createdAt = v;
	}

	public LocalDateTime getExpiresAt() {
		return expiresAt;
	}

	public void setExpiresAt(LocalDateTime v) {
		expiresAt = v;
	}

	public Long getMaxClicks() {
		return maxClicks;
	}

	public void setMaxClicks(Long v) {
		maxClicks = v;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean v) {
		active = v;
	}

	public long getClickCount() {
		return clickCount;
	}

	public void setClickCount(long v) {
		clickCount = v;
	}

	public String getTags() {
		return tags;
	}

	public void setTags(String v) {
		tags = v;
	}

	public String getFolder() {
		return folder;
	}

	public void setFolder(String v) {
		folder = v;
	}

	public String getPasswordHash() {
		return passwordHash;
	}

	public void setPasswordHash(String v) {
		passwordHash = v;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User v) {
		user = v;
	}
}
