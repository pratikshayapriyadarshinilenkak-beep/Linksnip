package com.linksnip.dto;

import java.util.List;
import java.util.Map;

public record AnalyticsResponse(Long linkId, long totalClicks, List<Map<String, Object>> clicks) {
}
