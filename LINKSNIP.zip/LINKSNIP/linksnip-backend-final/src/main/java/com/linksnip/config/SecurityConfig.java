package com.linksnip.config;

import com.linksnip.security.JwtAuthenticationFilter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
public class SecurityConfig {

    private final JwtAuthenticationFilter jwt;

    public SecurityConfig(JwtAuthenticationFilter jwt) {
        this.jwt = jwt;
    }

    @Bean
    PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    SecurityFilterChain filter(HttpSecurity http) throws Exception {

        return http
                .csrf(c -> c.disable())
                .cors(c -> {})
                .sessionManagement(s ->
                        s.sessionCreationPolicy(SessionCreationPolicy.STATELESS)
                )
                .authorizeHttpRequests(a -> a

                        // Authentication
                        .requestMatchers("/api/auth/**").permitAll()

                        // Create short link
                        .requestMatchers(HttpMethod.POST, "/api/links").permitAll()

                        // User's links
                        .requestMatchers(
                                "/api/links/mine",
                                "/api/links/mine/**"
                        ).authenticated()

                        // Analytics
                        .requestMatchers("/api/analytics/**").authenticated()

                        // QR Code
                        .requestMatchers("/api/qr/**").authenticated()

                        // CSV Export
                        .requestMatchers("/api/export/**").authenticated()

                        // Bulk Import
                        .requestMatchers("/api/bulk/**").authenticated()

                        // Get one link
                        .requestMatchers(
                                HttpMethod.GET,
                                "/api/links/*"
                        ).authenticated()

                        // Update link
                        .requestMatchers(
                                HttpMethod.PUT,
                                "/api/links/*"
                        ).authenticated()

                        // Delete link
                        .requestMatchers(
                                HttpMethod.DELETE,
                                "/api/links/*"
                        ).authenticated()

                        // Short URL redirect
                        .requestMatchers(
                                HttpMethod.GET,
                                "/{code}"
                        ).permitAll()

                        // Other requests
                        .anyRequest().permitAll()
                )
                .addFilterBefore(
                        jwt,
                        UsernamePasswordAuthenticationFilter.class
                )
                .build();
    }
}
