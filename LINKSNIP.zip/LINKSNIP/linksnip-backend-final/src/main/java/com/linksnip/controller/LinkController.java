package com.linksnip.controller;

import com.linksnip.dto.*;
import com.linksnip.service.LinkService;
import jakarta.validation.Valid;
import org.springframework.http.*;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/links")
@CrossOrigin(origins = { "http://localhost:3000", "http://localhost:5173" })
public class LinkController {
	private final LinkService service;

	public LinkController(LinkService service) {
		this.service = service;
	}

	@PostMapping
	public ResponseEntity<LinkResponse> create(@Valid @RequestBody CreateLinkRequest r, Authentication a) {
		String email = a == null ? null : a.getName();
		return ResponseEntity.status(HttpStatus.CREATED).body(service.create(r, email));
	}

	@GetMapping("/mine")
	public List<LinkResponse> mine(Authentication a) {
		return service.mine(a.getName());
	}

	@GetMapping("/{id}")
	public LinkResponse get(@PathVariable Long id, Authentication a) {
		return service.getMine(id, a.getName());
	}

	@PutMapping("/{id}")
	public LinkResponse update(@PathVariable Long id, @Valid @RequestBody UpdateLinkRequest r, Authentication a) {
		return service.update(id, a.getName(), r);
	}

	@DeleteMapping("/{id}")
	@ResponseStatus(HttpStatus.NO_CONTENT)
	public void delete(@PathVariable Long id, Authentication a) {
		service.delete(id, a.getName());
	}
}
