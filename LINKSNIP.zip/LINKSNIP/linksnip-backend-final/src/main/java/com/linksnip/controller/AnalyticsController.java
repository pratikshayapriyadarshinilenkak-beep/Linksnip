package com.linksnip.controller;

import com.linksnip.dto.AnalyticsResponse;
import com.linksnip.service.AnalyticsService;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/analytics")
public class AnalyticsController {
	private final AnalyticsService service;

	public AnalyticsController(AnalyticsService service) {
		this.service = service;
	}

	@GetMapping("/{linkId}")
	public AnalyticsResponse get(@PathVariable Long linkId, Authentication a) {
		return service.get(linkId, a.getName());
	}
}
