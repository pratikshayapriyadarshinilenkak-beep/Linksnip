package com.linksnip.service;

import com.linksnip.dto.AnalyticsResponse;
import com.linksnip.entity.ClickEvent;
import com.linksnip.entity.Link;
import com.linksnip.exception.ResourceNotFoundException;
import com.linksnip.repository.ClickEventRepository;
import com.linksnip.repository.LinkRepository;
import org.springframework.stereotype.Service;
import java.util.*;

@Service
public class AnalyticsService {
	private final ClickEventRepository events;
	private final LinkRepository links;

	public AnalyticsService(ClickEventRepository events, LinkRepository links) {
		this.events = events;
		this.links = links;
	}

	public AnalyticsResponse get(Long id, String email) {
		Link l = links.findByIdAndUserEmail(id, email)
				.orElseThrow(() -> new ResourceNotFoundException("Link not found"));
		List<Map<String, Object>> rows = events.findByLinkIdOrderByClickedAtDesc(id).stream().map(this::map).toList();
		return new AnalyticsResponse(id, l.getClickCount(), rows);
	}

	private Map<String, Object> map(ClickEvent e) {
		Map<String, Object> m = new LinkedHashMap<>();
		m.put("timestamp", e.getClickedAt());
		m.put("ip", e.getIpAddress());
		m.put("referrer", e.getReferrer());
		m.put("device", e.getDevice());
		m.put("browser", e.getBrowser());
		m.put("country", e.getCountry());
		m.put("city", e.getCity());
		return m;
	}
}
