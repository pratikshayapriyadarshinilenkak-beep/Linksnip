package com.linksnip.service;

import com.linksnip.dto.*;
import com.linksnip.entity.User;
import com.linksnip.repository.UserRepository;
import com.linksnip.security.JwtService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AuthService {
	private final UserRepository users;
	private final PasswordEncoder encoder;
	private final JwtService jwt;

	public AuthService(UserRepository users, PasswordEncoder encoder, JwtService jwt) {
		this.users = users;
		this.encoder = encoder;
		this.jwt = jwt;
	}

	public AuthResponse register(RegisterRequest r) {
		String e = r.email().trim().toLowerCase();
		if (users.existsByEmail(e))
			throw new IllegalArgumentException("Email is already registered");
		User u = new User();
		u.setEmail(e);
		u.setPassword(encoder.encode(r.password()));
		u.setEnabled(true);
		users.save(u);
		return new AuthResponse(jwt.generate(e), e);
	}

	public AuthResponse login(LoginRequest r) {
		String e = r.email().trim().toLowerCase();
		User u = users.findByEmail(e).orElseThrow(() -> new IllegalArgumentException("Invalid email or password"));
		if (!encoder.matches(r.password(), u.getPassword()))
			throw new IllegalArgumentException("Invalid email or password");
		return new AuthResponse(jwt.generate(e), e);
	}
}
